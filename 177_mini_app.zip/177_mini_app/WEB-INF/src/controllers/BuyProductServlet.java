package controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/purchase.do")
public class BuyProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data from the request
        String productName = request.getParameter("productName");
        String productPriceStr = request.getParameter("productPrice");
        String quantityStr = request.getParameter("quantity");

        try {
            double productPrice = Double.parseDouble(productPriceStr);
            int quantity = Integer.parseInt(quantityStr);

            // Calculate total price
            double totalPrice = productPrice * quantity;

            // Set the results in the request object to display in the JSP
            request.setAttribute("productName", productName);
            request.setAttribute("totalPrice", totalPrice);
            request.setAttribute("quantity", quantity);

            // Forward to a result JSP page
            request.getRequestDispatcher("buy_product_result.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            // Handle invalid number format exception
            request.setAttribute("message", "Invalid price or quantity format.");
            request.getRequestDispatcher("buy_product.jsp").forward(request, response);
        }
    }
}
