package controllers;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

import java.io.*;
import java.util.List;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import models.User;
import models.UserType;

@WebServlet("/signup.do")
public class SignUpServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.getRequestDispatcher("signup.jsp").forward(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String forwardURL = "signup.jsp";

        if(ServletFileUpload.isMultipartContent(request)) {
            ServletContext context = getServletContext();

            try {
                List<FileItem> list = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
                String uploadPath = context.getRealPath("/WEB-INF/uploads");

                User user = new User();

                for(FileItem item : list) {
                    if(item.isFormField()) {
                        String fieldName = item.getFieldName();

                        if(fieldName.equals("user_name")) {
                            user.setUserName(item.getString());
                        } else if(fieldName.equals("email")) {
                            user.setEmail(item.getString());                            
                        } else if(fieldName.equals("password")) {
                            user.setPassword(item.getString());
                        } else if(fieldName.equals("user_type")) {
                            user.setUserType(new UserType(Integer.parseInt(item.getString())));
                        } 
                    } else {    
                        File myFolderPath = new File(uploadPath, user.getEmail());
                        myFolderPath.mkdir();

                        File productsFolder = new File(myFolderPath, "products");
                        productsFolder.mkdir();

                        String originalFileName = item.getName();
                        File file = new File(myFolderPath, originalFileName);
                        user.setMyPic(originalFileName);

                        try {
                            item.write(file); 
                        } catch(Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

                if(user.signupUser()) {
                    forwardURL = "signin.jsp";
                }
            } catch(FileUploadException e) {
                e.printStackTrace();
            }
        }        
        
        request.getRequestDispatcher(forwardURL).forward(request, response);
    }   
}