package utils;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class SMSSender {
    static final String ACCOUNT_SID = "AC1862d50c74455dc03d1927c30f364156";
    static final String AUTH_TOKEN = "2aa6c45028318b9b04e7b72f848ef6b9";

    public static void sendOTP(String phone, String otp) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
        Message message = Message.creator(
            new com.twilio.type.PhoneNumber("+91"+phone),
                new com.twilio.type.PhoneNumber("+19548748727"),
                "Welcome to ISRDC! OTP: "+otp)
            .create();

        System.out.println(message.getBody());
    }
}
